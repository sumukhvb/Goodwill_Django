from flask import Flask, render_template
from butter_cms import ButterCMS
client = ButterCMS('fe24aecaf5a4ed78ad167e1a820b3e7fd04b90b2')

app=Flask(_name_)

@app.route('/', methods=['POST','GET'])
def home():
    homepage = client.posts.get('about-us')
    return render_template('home.html', obj=homepage['data']['body'])

if _name_ == "_main_": app.run(debug=True)pi